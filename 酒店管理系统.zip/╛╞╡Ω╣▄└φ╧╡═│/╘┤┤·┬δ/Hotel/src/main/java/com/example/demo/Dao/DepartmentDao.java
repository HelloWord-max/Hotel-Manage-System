package com.example.demo.Dao;

import java.util.HashMap;
import java.util.Map;

import com.example.demo.pojo.User;

public class DepartmentDao {
	private static Map<Integer, User> user=null;
	
	static {
		user=new HashMap<Integer, User>();
	}
	
	
}
