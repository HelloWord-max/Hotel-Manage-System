package com.example.demo.config;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;
//import org.springframework.web.servlet.ModelAndView;


//登录拦截器
public class LoginHandlerInterceptor implements HandlerInterceptor{

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
			Object loginuser=request.getSession().getAttribute("loginuser");//获取session的用户信息
			Object admin=request.getSession().getAttribute("admin");//获取session的用户信息
			
			if(loginuser==null&&admin==null)//面如果session不存在登录用户，拦截
			{
				request.getRequestDispatcher("/login.html").forward(request, response);
			}
			else//如果session存在登录用户，则可以直接进入主页
			{
				return true;
			}
			return false;
	}

	
	
}
