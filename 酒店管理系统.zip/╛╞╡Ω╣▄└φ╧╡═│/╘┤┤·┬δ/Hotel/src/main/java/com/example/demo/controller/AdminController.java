package com.example.demo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.entity.Admin;
import com.example.demo.service.impl.AdminServicelmpl;


@Controller
public class AdminController {
	@Autowired
	private AdminServicelmpl adminServicelmpl;
	
	@RequestMapping("/admin")
	public String main(Model model,HttpServletRequest request,HttpSession session) {
		String adminaccount=request.getParameter("adminaccount");
		String passward=request.getParameter("password");
		Admin admin=adminServicelmpl.findAdminByAdminname(adminaccount);
		if(admin!=null)//存在账户
		{
			if(passward!=null)
			{
				if(admin.getPassward().replaceAll(" ", "").equals(passward.replaceAll(" ", "")))
				{
					session.setAttribute("admin", adminaccount);
					return "redirect:/userinfo";
				}
			}
		}
		model.addAttribute("msg","用户名或者密码错误！");
		
		model.addAttribute("admin", admin);
		return "adminlogin";
	}
}
