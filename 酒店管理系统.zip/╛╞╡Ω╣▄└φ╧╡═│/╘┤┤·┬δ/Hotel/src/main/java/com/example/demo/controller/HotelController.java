package com.example.demo.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entity.Hotel;
import com.example.demo.service.impl.HotelServiceImpl;

@Controller
public class HotelController {
	@Autowired
	private HotelServiceImpl hotelServiceImpl;
	
	@RequestMapping("/main")
	public String main(Model model) {
		List<Hotel> hotellist=hotelServiceImpl.findHotelAll();
		model.addAttribute("hotellist", hotellist);
		return "Main";
	}
	
	@RequestMapping("/search")
	public String main(@RequestParam("hotelname") String hotelname,@RequestParam("location") String location,Model model) {
		if(location.equals("location_all"))
		{
			location="";
		}
		List<Hotel> hotellist=hotelServiceImpl.findHotelByName(hotelname,location);
		model.addAttribute("hotellist", hotellist);
		return "Main";
	}
	
}
