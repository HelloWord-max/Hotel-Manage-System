package com.example.demo.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.entity.User;
import com.example.demo.service.UserService;
import com.example.demo.service.impl.UserServiceImpl;

@Controller
public class LoginController {
	
	@Autowired
	private UserServiceImpl userServiceImpl;
	
	@PostMapping("/user/login")
	public String login(@RequestParam("username") String username,@RequestParam("userpassword") String userpassword,Model model,HttpSession session) {
		User user= userServiceImpl.findByName(username);
		if(user!=null)//存在账户
		{
			if(userpassword!=null)
			{
				if(user.getpassward().replaceAll(" ", "").equals(userpassword.replaceAll(" ", "")))
				{
					session.setAttribute("loginuser", username);
					return "redirect:/main";
				}
			}
		}
		model.addAttribute("msg","用户名或者密码错误！");
		return "login";
	}
	
	
	
	@RequestMapping("/user/register")
	public String register(@RequestParam("account_num") String username,@RequestParam("rg-passward") String userpassword,@RequestParam("rg-sure-passward") String suerpassword,Model model) {
		User user= userServiceImpl.findByName(username);
		if(user!=null)//存在账户
		{
			model.addAttribute("msg","账户已经存在！");
		}
		else
		{
			if(userpassword!=null)
			{
				userServiceImpl.addUser(username, userpassword);
				return "login";
			}
		}
		return "login";
	}
}
