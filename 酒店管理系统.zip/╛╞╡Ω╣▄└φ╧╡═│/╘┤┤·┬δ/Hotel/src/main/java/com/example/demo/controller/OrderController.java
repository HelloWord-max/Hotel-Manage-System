package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entity.User_Order;
import com.example.demo.service.impl.Order_numServicelmpl;
import com.example.demo.service.impl.RoomServiceImpl;
import com.example.demo.service.impl.UserServiceImpl;
import com.example.demo.service.impl.User_orderServiceImpl;

@Controller
public class OrderController {
	@Autowired
	User_orderServiceImpl user_orderServiceImpl;
	@Autowired
	Order_numServicelmpl order_numServicelmpl;
	@Autowired
	RoomServiceImpl roomServiceImpl;
	@Autowired
	UserServiceImpl userServiceImpl;

	
	@RequestMapping("/cancel")
	public String cancel(@RequestParam("order_num") String order_num) {
		int ordernum=(int)Integer.valueOf(order_num);
		User_Order user_order= user_orderServiceImpl.findByOrder_num(ordernum);
		String username =user_order.getUsername();
		String businessid= user_order.getBusinessid();
		String bedtype=user_order.getBedtype();
		Float Paidprice=user_order.getPaidprice();
		
		roomServiceImpl.Cancel_Order(businessid,bedtype);
		
		userServiceImpl.Draw_back(Paidprice,username);

		System.out.println(businessid+"----"+bedtype);
		
		user_orderServiceImpl.Cancle_Order(ordernum);

		
		return "redirect:/order";
	}
}
