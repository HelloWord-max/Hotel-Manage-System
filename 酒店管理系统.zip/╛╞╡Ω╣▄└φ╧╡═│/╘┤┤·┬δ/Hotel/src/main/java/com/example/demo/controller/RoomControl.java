package com.example.demo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entity.Order_num;
import com.example.demo.entity.Rooms;
import com.example.demo.entity.User;
import com.example.demo.entity.User_Order;
import com.example.demo.service.impl.Order_numServicelmpl;
import com.example.demo.service.impl.RoomServiceImpl;
import com.example.demo.service.impl.UserServiceImpl;
import com.example.demo.service.impl.User_orderServiceImpl;

@Controller
public class RoomControl {
	@Autowired
	private RoomServiceImpl roomServiceImpl;
	@Autowired
	User_orderServiceImpl user_orderServiceImpl;
	@Autowired
	UserServiceImpl userServiceImpl;
	@Autowired
	Order_numServicelmpl order_numServicelmpl;
	
	@RequestMapping("/hotel_more_info")
	public String hotelifno(@RequestParam("show") String show,@RequestParam("businessid") String businessid,Model model) {
		List<Rooms> rooms=roomServiceImpl.findRoomByBusinessId(businessid);
		model.addAttribute("rooms", rooms);
		
		if(show.equals("1"))
		{
			model.addAttribute("tip", "预定成功");
		}
		else if(show.equals("0"))
		{
			model.addAttribute("tip", "预定失败,金额不足,请充值");
		}
		else if(show.equals("2"))
		{
			model.addAttribute("tip", "预定失败,你已经预订过了");
		}
		model.addAttribute("show", show);
		return "hotel_info";
	}
	
	@RequestMapping("/reserve")
	public String reserve(HttpServletRequest request,@RequestParam("businessid") String businessid,@RequestParam("bedtype") String bedtype,@RequestParam("paidprice") String price,Model model) {
		String username= request.getSession().getAttribute("loginuser").toString();
		User user=userServiceImpl.findByName(username);
		Float balance= user.getBalance();
		Float paidprice=Float.valueOf(price);
		businessid=businessid.replaceAll(" ", "");
		List<User_Order> user_order_list= user_orderServiceImpl.findIncompleteOrderByUserName(username);
		for(int i=0;i<user_order_list.size();i++)
		{
			if(user_order_list.get(i).getBusinessid().replaceAll(" ", "").equals(businessid)&&user_order_list.get(i).getState().replaceAll(" ", "").equals("0")&&user_order_list.get(i).getBedtype().replaceAll(" ", "").equals(bedtype.replaceAll(" ", "")))
			{
				return "redirect:/hotel_more_info?businessid="+businessid+"&show=2";//+"&bedtype="+bedtype
			}
		}
		if(balance>=paidprice)
		{
			roomServiceImpl.reserve(businessid,bedtype);
			System.out.println("1111111111111111111111111");
			Order_num orde_rnum= order_numServicelmpl.findOrder_num();
			System.out.println("2222222222222222222222");
			user_orderServiceImpl.AddOrder(username,businessid,paidprice,bedtype,orde_rnum.getOrder_num());
			order_numServicelmpl.setOrder_num();
			userServiceImpl.pay(username, paidprice);
			
			return "redirect:/hotel_more_info?businessid="+businessid+"&show=1";
		}
		
		
		return "redirect:/hotel_more_info?businessid="+businessid+"&show=0";
	}
}
