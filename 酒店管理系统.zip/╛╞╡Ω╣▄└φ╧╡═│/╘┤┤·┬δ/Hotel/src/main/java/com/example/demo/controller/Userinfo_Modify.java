package com.example.demo.controller;


import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.example.demo.service.impl.UserServiceImpl;

@Controller
public class Userinfo_Modify {
	@Autowired
	private UserServiceImpl userServiceImpl;
	
	@RequestMapping("/umodify_userinfo")
	public String umodify_userifno(HttpServletRequest request,HttpServletResponse response,Model model) {
		String username= request.getSession().getAttribute("loginuser").toString();
        MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest) request;
        List<MultipartFile> files = multipartHttpServletRequest.getFiles("head_img");
        BufferedOutputStream stream = null;
        MultipartFile file = null;
       for (int i = 0; i < files.size(); ++i) {
	        file = files.get(i);
	        if (!file.isEmpty()) {
	        	try {
	        			File[] currentfiles = new File("G:/项目/javaspring/Hotel/src/main/resources/static/userheadimgs/").listFiles(); 
	        			for(int j=0;j<currentfiles.length;j++){
	                        String tmp=currentfiles[j].getName();
	                        if(tmp.equals(username+".jpg"))
	                        {
	                        	
	                        }
	                    }
		        		String fullfilePath = "G:/项目/javaspring/Hotel/src/main/resources/static/userheadimgs/" +username+".jpg";//自己设定的文件目录
		        	    byte[] bytes = file.getBytes();
				        stream = new BufferedOutputStream(new FileOutputStream(
				        new File(fullfilePath)));
				        stream.write(bytes);
				        stream.close();
				        String head_imgpath= "/userheadimgs/"+username+".jpg";
						userServiceImpl.modifyHead_img(username, head_imgpath);
	        	} catch (Exception e) {
		        stream = null;
	        	}
	        } 
        }
        
        
		
		String nickname= request.getParameter("nickname");
		if(nickname!=null)
		{
			userServiceImpl.modifyNickname(username, nickname);
		}
		else
		{
			userServiceImpl.modifyNickname(username, "");
		}
		
		String Personal_label= request.getParameter("Personal_label");
		if(Personal_label!=null)
		{
			userServiceImpl.modifyPersonal_label(username, Personal_label);
		}
		else
		{
			userServiceImpl.modifyPersonal_label(username, "");
		}
		
		String sex= request.getParameter("sex");
		if(sex!=null)
		{
			userServiceImpl.modifySex(username, sex);
		}
		else
		{
			userServiceImpl.modifySex(username, "");
		}
		
		String birthday= request.getParameter("birthday");
		if(birthday!=null)
		{
			userServiceImpl.modifyBirthday(username, birthday);
		}
		else
		{
			userServiceImpl.modifyBirthday(username, "");
		}
		
		return "redirect:info";
	}
	
	
	@RequestMapping("/amodify_userinfo")
	public String amodify_userifno(HttpServletRequest request,HttpServletResponse response,Model model) {
		String username= request.getParameter("username");
		String nickname= request.getParameter("nickname");
		String Personal_label= request.getParameter("Personal_label");
		String sex= request.getParameter("sex");
		String birthday= request.getParameter("birthday");
		if(nickname!=null)
		{
			userServiceImpl.modifyNickname(username, nickname);
		}
		else
		{
			userServiceImpl.modifyNickname(username, "");
		}
		
//		String Personal_label= request.getParameter("Personal_label");
		if(Personal_label!=null)
		{
			userServiceImpl.modifyPersonal_label(username, Personal_label);
		}
		else
		{
			userServiceImpl.modifyPersonal_label(username, "");
		}
		
//		String sex= request.getParameter("sex");
		if(sex!=null)
		{
			userServiceImpl.modifySex(username, sex);
		}
		else
		{
			userServiceImpl.modifySex(username, "");
		}
		
//		String birthday= request.getParameter("birthday");
		if(birthday!=null)
		{
			userServiceImpl.modifyBirthday(username, birthday);
		}
		else
		{
			userServiceImpl.modifyBirthday(username, "");
		}
		
		return "redirect:userinfo";
	}
	
	
	@RequestMapping("/delet_user")
	public String delet_user(@RequestParam("username") String username) {
		userServiceImpl.delete_User(username);
		return "redirect:userinfo";
	}
	
	@RequestMapping("/recharge")
	public String Recharge(@RequestParam("money") String money,HttpServletRequest request) {
		String username= request.getSession().getAttribute("loginuser").toString();
		userServiceImpl.Recharge(username,money);
		return "redirect:wallet";
	}
	
}
