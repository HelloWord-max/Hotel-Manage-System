package com.example.demo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;	

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entity.Rooms;
import com.example.demo.entity.User;
import com.example.demo.entity.User_Order;
import com.example.demo.service.impl.RoomServiceImpl;
import com.example.demo.service.impl.UserServiceImpl;
import com.example.demo.service.impl.User_orderServiceImpl;

@Controller
public class account_jump {
	@Autowired
	private UserServiceImpl userServiceImpl;
	@Autowired
	private User_orderServiceImpl user_orderServiceImpl;
	@Autowired
	private RoomServiceImpl roomServiceImpl;
	
	@RequestMapping("/order")
	public String main(HttpServletRequest request, Model model)
	{
		String username= request.getSession().getAttribute("loginuser").toString();
		
		List<User_Order> User_Order_Complete_list= user_orderServiceImpl.findCompleteOrderByUserName(username);
		
		for(int i=0;i<User_Order_Complete_list.size();i++)
		{
			List<Rooms> room =roomServiceImpl.findRoomByBusinessId_bedtype(User_Order_Complete_list.get(i).getBusinessid(), User_Order_Complete_list.get(i).getBedtype());
			User_Order_Complete_list.get(i).setImgpath(room.get(0).getRoomimgspath());
		}
		
		model.addAttribute("User_Order_Complete_list", User_Order_Complete_list);
		
		List<User_Order> User_Order_InComplete_list= user_orderServiceImpl.findIncompleteOrderByUserName(username);
		
		
		for(int i=0;i<User_Order_InComplete_list.size();i++)
		{

			List<Rooms> room =roomServiceImpl.findRoomByBusinessId_bedtype(User_Order_InComplete_list.get(i).getBusinessid(), User_Order_InComplete_list.get(i).getBedtype());

			User_Order_InComplete_list.get(i).setImgpath(room.get(0).getRoomimgspath());
		}
		
		System.out.println(User_Order_InComplete_list.size());
		
		model.addAttribute("User_Order_InComplete_list", User_Order_InComplete_list);
		
		
		List<User_Order> User_Order_living_list= user_orderServiceImpl.findLivingOrderByUserName(username);
		
		
		for(int i=0;i<User_Order_living_list.size();i++)
		{

			List<Rooms> room =roomServiceImpl.findRoomByBusinessId_bedtype(User_Order_InComplete_list.get(i).getBusinessid(), User_Order_InComplete_list.get(i).getBedtype());

			User_Order_living_list.get(i).setImgpath(room.get(0).getRoomimgspath());
		}
		
		System.out.println(User_Order_living_list.size());
		
		model.addAttribute("User_Order_living_list", User_Order_living_list);
		
		
		return "User_orders";
	}
	
	@RequestMapping("/info")
	public String personal_data(HttpServletRequest request, Model model)
	{
		String username= request.getSession().getAttribute("loginuser").toString();
		User User_info= userServiceImpl.findByName(username);
		model.addAttribute("User_info", User_info);
		return "personal_data";
	}
	
	@RequestMapping("/userinfo")
	public String adminmainpage( Model model)
	{
		List<User> User_info_list= userServiceImpl.findUserAll();
		model.addAttribute("User_info_list", User_info_list);
		return "admin_operate_main_page";
	}
	
	@RequestMapping("/wallet")
	public String walletpage(HttpServletRequest request,Model model)
	{
		String username= request.getSession().getAttribute("loginuser").toString();
		User User_info= userServiceImpl.findByName(username);
		model.addAttribute("User_info", User_info);
		return "balance";
	}
	
	@RequestMapping("/quit")
	public String walletpage(HttpServletRequest request)
	{
		
		request.getSession().removeAttribute("loginuser");
		
		return "login";
	}
	
}
