package com.example.demo.entity;

public class Admin {
	private String adminaccount;
	private String passward;
	public String getAdminaccount() {
		return adminaccount;
	}
	public void setAdminaccount(String adminaccount) {
		this.adminaccount = adminaccount;
	}
	public String getPassward() {
		return passward;
	}
	public void setPassward(String passward) {
		this.passward = passward;
	}
}
