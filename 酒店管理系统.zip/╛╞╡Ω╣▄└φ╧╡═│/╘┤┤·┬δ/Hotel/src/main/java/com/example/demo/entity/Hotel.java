package com.example.demo.entity;

import java.util.List;

public class Hotel {
	private String businessid;
	private String hotelname;
	private String hotelinfo;
	private String hotelimgspath;
	private String[] hotelimgspathlist;
	private float hotelprice;
	private String hoteladdress;
	private List<Hotel> hotels;
	public String getBusinessid() {
		return businessid.replaceAll(" ", "");
	}
	public void setBusinessid(String businessid) {
		this.businessid = businessid;
	}
	public String getHotelname() {
		return hotelname.replaceAll(" ", "");
	}
	public void setHotelname(String hotelname) {
		this.hotelname = hotelname;
	}
	public String getHotelinfo() {
		return hotelinfo.replaceAll(" ", "");
	}
	public void setHotelinfo(String hotelinfo) {
		this.hotelinfo = hotelinfo;
	}
	public String getHotelimgspath() {
		return hotelimgspath.replaceAll(" ", "");
	}
	public void setHotelimgspath(String hotelimgspath) {
		this.hotelimgspath = hotelimgspath;
	}
	public float getHotelprice() {
		return hotelprice;
	}
	public void setHotelprice(float hotelprice) {
		this.hotelprice = hotelprice;
	}
	public String getHoteladdress() {
		return hoteladdress.replaceAll(" ", "");
	}
	public void setHoteladdress(String hoteladdress) {
		this.hoteladdress = hoteladdress;
	}
	public List<Hotel> getHotels() {
		return hotels;
	}
	public void setHotels(List<Hotel> hotels) {
		this.hotels = hotels;
	}
	public String[] getHotelimgspathlist() {
		hotelimgspathlist=hotelimgspath.split(";");
		return hotelimgspathlist;
	}
	public void setHotelimgspathlist(String[] hotelimgspathlist) {
		this.hotelimgspathlist = hotelimgspathlist;
	}
	
}
