package com.example.demo.entity;

public class Order_num {
	private int order_num;

	public int getOrder_num() {
		return order_num;
	}

	public void setOrder_num(int order_num) {
		this.order_num = order_num;
	}
}
