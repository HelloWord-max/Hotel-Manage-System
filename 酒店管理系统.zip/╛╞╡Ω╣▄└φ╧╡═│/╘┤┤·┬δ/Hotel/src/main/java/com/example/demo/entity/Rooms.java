package com.example.demo.entity;

import java.util.List;

public class Rooms {
	private String businessid;
	private String roomimgspath;
	private String[] roomimgspathlist;
	private float roomprice;
	private String bedtype;
	public String getBedtype() {
		return bedtype;
	}
	public void setBedtype(String bedtype) {
		this.bedtype = bedtype;
	}
	public int getSurplus() {
		return surplus;
	}
	public void setSurplus(int surplus) {
		this.surplus = surplus;
	}
	private int  surplus;
	private List<Hotel> rooms;
	public String getRoomimgspath() {
		return roomimgspath.replaceAll(" ", "");
	}
	public void setRoomimgspath(String roomimgspath) {
		this.roomimgspath = roomimgspath;
	}
	public String[] getRoomimgspathlist() {
		return roomimgspathlist;
	}
	public void setRoomimgspathlist(String[] roomimgspathlist) {
		roomimgspathlist=roomimgspath.split(";");
		this.roomimgspathlist = roomimgspathlist;
	}
	public float getRoomprice() {
		return roomprice;
	}
	public void setRoomprice(float roomprice) {
		this.roomprice = roomprice;
	}
	public List<Hotel> getRooms() {
		return rooms;
	}
	public void setRooms(List<Hotel> rooms) {
		this.rooms = rooms;
	}
	public String getBusinessid() {
		return businessid;
	}
	public void setBusinessid(String businessid) {
		this.businessid = businessid;
	}
}
