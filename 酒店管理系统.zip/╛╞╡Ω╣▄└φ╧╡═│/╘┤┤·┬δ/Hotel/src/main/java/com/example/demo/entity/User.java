package com.example.demo.entity;

import java.util.List;


public class User{
	private String username;
	private String passward;
	private String nickname="";
	private String Personal_label="";
	private String head_img="";
	private String sex="";
	private String birthday="";
	private float balance=0;
	private List<User> userlist;
	public String getusername() {
		return username;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassward() {
		return passward;
	}
	public void setPassward(String passward) {
		this.passward = passward;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getPersonal_label() {
		return Personal_label;
	}
	public void setPersonal_label(String personal_label) {
		Personal_label = personal_label;
	}
	public String getSex() {
		return sex.replaceAll(" ", "");
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public void setusername(String username) {
		this.username = username;
	}
	public String getpassward() {
		return passward;
	}
	public void setpassward(String passward) {
		this.passward = passward;
	}
	public String getHead_img() {
		return head_img;
	}
	public void setHead_img(String head_img) {
		this.head_img = head_img;
	}
	public List<User> getUserlist() {
		return userlist;
	}
	public void setUserlist(List<User> userlist) {
		this.userlist = userlist;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
}
