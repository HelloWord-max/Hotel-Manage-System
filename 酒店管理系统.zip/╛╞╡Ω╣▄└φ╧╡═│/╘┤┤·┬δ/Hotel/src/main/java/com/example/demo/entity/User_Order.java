package com.example.demo.entity;

import java.util.List;

public class User_Order {
	private String username;
	private String businessid;
	private String imgpath="";
	private float paidprice;
	private String bedtype;
	private String state;
	private int order_num;
	private List<User_Order> User_Order_list;
	public String getUsername() {
		return username.replace(" ", "");
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getBusinessid() {
		return businessid.replace(" ", "");
	}
	public void setBusinessid(String businessid) {
		this.businessid = businessid;
	}
	public float getPaidprice() {
		return paidprice;
	}
	public void setPaidprice(float paidprice) {
		this.paidprice = paidprice;
	}
	public String getBedtype() {
		return bedtype.replace(" ", "");
	}
	public void setBedtype(String bedtype) {
		this.bedtype = bedtype;
	}
	public String getState() {
		return state.replace(" ", "");
	}
	public void setState(String state) {
		this.state = state;
	}
	public List<User_Order> getUser_Order_list() {
		return User_Order_list;
	}
	public void setUser_Order_list(List<User_Order> user_Order_list) {
		User_Order_list = user_Order_list;
	}
	public String getImgpath() {
		return imgpath;
	}
	public void setImgpath(String imgpath) {
		this.imgpath = imgpath;
	}
	public int getOrder_num() {
		return order_num;
	}
	public void setOrder_num(int order_num) {
		this.order_num = order_num;
	}
}
