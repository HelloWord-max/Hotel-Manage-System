package com.example.demo.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Admin;

@Mapper
@Repository
public interface AdminMapper {
	public Admin findAdminByAdminname(String adminaccount) ;
}
