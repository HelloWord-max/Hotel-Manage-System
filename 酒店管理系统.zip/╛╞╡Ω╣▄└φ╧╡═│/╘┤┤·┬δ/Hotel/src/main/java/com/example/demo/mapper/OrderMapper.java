package com.example.demo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.User_Order;

@Mapper
@Repository
public interface OrderMapper {
	public List<User_Order> findIncompleteOrderByUserName(String username);
	
	public List<User_Order> findCompleteOrderByUserName(String username);
	
	public List<User_Order> findLivingOrderByUserName(String username);
	
	public void AddOrder(String username,String businessid,Float paidprice,String bedtype,int ord_num);
	
	
	public User_Order findByOrder_num(int order_num);
	
	public void Cancle_Order(int ordernum);
	
}
