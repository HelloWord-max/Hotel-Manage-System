package com.example.demo.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Order_num;



@Mapper
@Repository
public interface Order_numMapper {
	
	public Order_num findOrder_num();
	
	public void setOrder_num() ;
}
