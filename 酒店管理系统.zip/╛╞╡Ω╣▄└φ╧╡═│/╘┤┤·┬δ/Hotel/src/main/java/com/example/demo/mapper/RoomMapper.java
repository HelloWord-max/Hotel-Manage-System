package com.example.demo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Rooms;

@Mapper
@Repository
public interface RoomMapper {
	public List<Rooms> findRoomByBusinessId(String Id);
	
	public void reserve(String businessid,String bedtype);
	
	public List<Rooms> findRoomByBusinessId_bedtype(String businessid,String bedtype);
	
	public void Cancel_Order(String businessid,String bedtype);
	
}
