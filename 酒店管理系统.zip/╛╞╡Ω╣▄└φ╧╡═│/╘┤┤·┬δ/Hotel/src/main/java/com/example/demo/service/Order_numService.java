package com.example.demo.service;

import com.example.demo.entity.Order_num;

public interface Order_numService {
	public Order_num findOrder_num() ;
	
	public void setOrder_num() ;
}
