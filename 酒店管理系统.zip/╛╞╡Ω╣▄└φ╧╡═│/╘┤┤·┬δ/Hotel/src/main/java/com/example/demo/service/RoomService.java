package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Rooms;

public interface RoomService {
	public Rooms findRoomByBusinessId(String Id);
	
	public void reserve(String businessid,String bedtype);
	
	public List<Rooms> findRoomByBusinessId_bedtype(String businessid,String bedtype);
	
	public void Cancel_Order(String businessid,String bedtype);
}
