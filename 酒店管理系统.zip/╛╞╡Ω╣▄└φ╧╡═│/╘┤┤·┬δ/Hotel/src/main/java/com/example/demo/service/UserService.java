package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.User;



public interface UserService {
	public User findByName(String username);
	
	public User findByPassward(String passward);
	
	public List<User> findUserAll();
	
	public void addUser(String name,String passward);
	
	public void modifyNickname(String username,String nickname);
	
	public void modifyPersonal_label(String username,String Personal_label);
	
	public void modifySex(String username,String sex);
	
	public void modifyBirthday(String username,String birthday);
	
	public void modifyHead_img(String username,String head_imgpath);
	
	public void delete_User(String username);
	
	public void Recharge(String username,String money);
	
	public void pay(String username,Float money);
	

	public void Draw_back(Float Paidprice,String username);
	
}
