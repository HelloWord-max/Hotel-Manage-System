package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.User_Order;

public interface User_orderService {
	public List<User_Order> findIncompleteOrderByUserName(String username);
	public List<User_Order> findcompleteOrderByUserName(String username);
	public List<User_Order> findLivingOrderByUserName(String username);
	public void AddOrder(String username,String businessid,Float paidprice,String bedtype,int ord_num);
	public User_Order findByOrder_num(int order_num);
	
	public User_Order Cancle_Order(String businessid,String bedtype);
}
