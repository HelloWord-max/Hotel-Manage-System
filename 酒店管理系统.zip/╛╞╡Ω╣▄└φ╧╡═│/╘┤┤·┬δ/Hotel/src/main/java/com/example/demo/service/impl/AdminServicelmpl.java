package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Admin;
import com.example.demo.mapper.AdminMapper;

@Service
public class AdminServicelmpl implements AdminMapper{
	@Autowired
	private AdminMapper adminMapper;
	
	@Override
	public Admin findAdminByAdminname(String adminaccount) {
		return adminMapper.findAdminByAdminname(adminaccount);
	}

	}
