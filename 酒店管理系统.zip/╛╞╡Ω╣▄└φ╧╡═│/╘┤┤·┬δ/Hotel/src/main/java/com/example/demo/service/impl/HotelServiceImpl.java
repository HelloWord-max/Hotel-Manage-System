package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Hotel;
import com.example.demo.mapper.HotelMapper;


@Service
public class HotelServiceImpl implements HotelMapper{
	@Autowired
	private HotelMapper hotelMapper;
	

	@Override
	public List<Hotel> findHotelAll() {
		// TODO Auto-generated method stub
		return hotelMapper.findHotelAll();
	}
	
	@Override
	public List<Hotel> findHotelByName(String hotelname,String location) {
		// TODO Auto-generated method stub
		return hotelMapper.findHotelByName(hotelname,location);
	}
	
	
}
