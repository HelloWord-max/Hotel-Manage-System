package com.example.demo.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Order_num;
import com.example.demo.mapper.Order_numMapper;

@Service
public class Order_numServicelmpl implements Order_numMapper{
	
	@Autowired
	private Order_numMapper order_numMapper;
	
	
	@Override
	public void setOrder_num() {
		order_numMapper.setOrder_num();
	}


	@Override
	public Order_num findOrder_num() {
		// TODO Auto-generated method stub
		return order_numMapper.findOrder_num();
	}
}
