package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Rooms;
import com.example.demo.mapper.RoomMapper;

@Service
public class RoomServiceImpl implements RoomMapper{
	@Autowired
	private RoomMapper roomMapper;
	
	@Override
	public List<Rooms> findRoomByBusinessId(String Id){
		return roomMapper.findRoomByBusinessId(Id);
	}
	
	@Override
	public void reserve(String businessid,String bedtype) {
		roomMapper.reserve(businessid,bedtype);
	}
	
	@Override
	public List<Rooms> findRoomByBusinessId_bedtype(String businessid,String bedtype){
		return roomMapper.findRoomByBusinessId_bedtype(businessid,bedtype);
	}
	
	@Override
	public void Cancel_Order(String businessid,String bedtype){
		roomMapper.Cancel_Order(businessid,bedtype);
	}
	
	
}
