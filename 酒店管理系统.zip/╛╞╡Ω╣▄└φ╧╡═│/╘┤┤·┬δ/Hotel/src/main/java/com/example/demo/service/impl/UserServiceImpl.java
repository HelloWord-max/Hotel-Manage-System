package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.User;
import com.example.demo.mapper.UserMapper;


@Service
public class UserServiceImpl implements UserMapper{
	@Autowired
	private UserMapper useMapper;
	
	@Override
	public User findByName(String username){
		return useMapper.findByName(username);
	}

	@Override
	public User findByPassward(String passward) {
		// TODO Auto-generated method stub
		return useMapper.findByName(passward);
	}

	@Override
	public List<User> findUserAll() {
		// TODO Auto-generated method stub
		return useMapper.findUserAll();
	}
	
	@Override
	public void addUser(String username,String passward){
		useMapper.addUser(username, passward);
	}
	
	@Override
	public void modifyNickname(String username,String nickname){//修改用户昵称
		useMapper.modifyNickname(username,nickname);
	}
	
	@Override
	public void modifyPersonal_label(String username,String Personal_label){//修改用户说明
		useMapper.modifyPersonal_label(username,Personal_label);
	}
	
	@Override
	public void modifySex(String username,String sex){//修改用户性别
		useMapper.modifySex(username,sex);
	}
	
	@Override
	public void modifyBirthday(String username,String birthday){//修改用户生日
		useMapper.modifyBirthday(username,birthday);
	}
	
	@Override
	public void modifyHead_img(String username,String head_imgpath){//修改用户头像
		useMapper.modifyHead_img(username, head_imgpath);
	}
	
	
	@Override
	public void delete_User(String username){//删除用户
		useMapper.delete_User(username);
	}
	
	@Override
	public void Recharge(String username,String money){//充值
		useMapper.Recharge(username,money);
	}
	
	@Override
	public void pay(String username,Float money){//充值
		useMapper.pay(username,money);
	}
	
	@Override
	public void Draw_back(Float Paidprice,String username){//退款
		useMapper.Draw_back(Paidprice,username);
	}
	
	
	
	
}
