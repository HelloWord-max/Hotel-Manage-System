package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.User_Order;
import com.example.demo.mapper.OrderMapper;

@Service
public class User_orderServiceImpl implements OrderMapper{
	@Autowired
	OrderMapper orderMapper;

	@Override
	public List<User_Order> findIncompleteOrderByUserName(String username) {
		// TODO Auto-generated method stub
		return orderMapper.findIncompleteOrderByUserName(username);
	}
	
	@Override
	public List<User_Order> findCompleteOrderByUserName(String username) {
		// TODO Auto-generated method stub
		return orderMapper.findCompleteOrderByUserName(username);
	}
	
	@Override
	public List<User_Order> findLivingOrderByUserName(String username) {
		// TODO Auto-generated method stub
		return orderMapper.findLivingOrderByUserName(username);
	}
	
	
	
	
	@Override
	public void AddOrder(String username,String businessid,Float paidprice,String bedtype,int ord_num) {
		// TODO Auto-generated method stub
		orderMapper.AddOrder(username, businessid, paidprice, bedtype,ord_num);
	}
	
	@Override
	public User_Order findByOrder_num(int order_num) {
		// TODO Auto-generated method stub
		return orderMapper.findByOrder_num(order_num);
	}
	
	@Override
	public void Cancle_Order(int ordernum) {
		// TODO Auto-generated method stub
		orderMapper.Cancle_Order(ordernum);
	}
	
	

}
