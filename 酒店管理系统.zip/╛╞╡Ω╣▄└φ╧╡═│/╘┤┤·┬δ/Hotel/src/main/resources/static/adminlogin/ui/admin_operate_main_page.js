

function show_business_info()
{
	var user_manage=document.getElementsByClassName("user_manage")[0];
	user_manage.style.display='none';	
	
	var business_manage=document.getElementsByClassName("business_manage")[0];
	business_manage.style.display='block';
}


function show_user_info()
{
	var business_manage=document.getElementsByClassName("business_manage")[0];
	business_manage.style.display='none';
	
	var user_manage=document.getElementsByClassName("user_manage")[0];
	user_manage.style.display='block';
}


function modify_userinfo(this_m){
	var sex_show=this_m.parentNode.parentNode.getElementsByClassName("sex_show")[0];
	var user_nickname= this_m.parentNode.parentNode.getElementsByClassName("user_nickname")[0];
	var Personal_label= this_m.parentNode.parentNode.getElementsByClassName("user_Personal_label")[0];
	var user_sex= this_m.parentNode.parentNode.getElementsByClassName("user_sex")[0];
	var user_birthday= this_m.parentNode.parentNode.getElementsByClassName("user_birthday")[0];
	user_nickname.disabled=false;
	user_nickname.style.border='inherit';
	
	Personal_label.disabled=false;
	Personal_label.style.border='inherit';
	
	user_sex.disabled=false;
	user_sex.style.border='inherit';
	
	sex_show.style.display='none';
	user_sex.style.display='inherit';
	
	user_birthday.disabled=false;
	user_birthday.style.border='inherit';
	
	var save=this_m.parentNode.parentNode.getElementsByClassName("save")[0];
	save.style.display='inherit';
	this_m.style.display='none';
}

function save_userinfo(this_s){
	var user_username= this_s.parentNode.parentNode.getElementsByClassName("user_name")[0];
	var user_nickname= this_s.parentNode.parentNode.getElementsByClassName("user_nickname")[0];
	var user_Personal_label= this_s.parentNode.parentNode.getElementsByClassName("user_Personal_label")[0];
	var user_sex= this_s.parentNode.parentNode.getElementsByClassName("user_sex")[0];
	var user_birthday= this_s.parentNode.parentNode.getElementsByClassName("user_birthday")[0];
	user_nickname.disabled=true;
	user_nickname.style.border='none';
	
	user_Personal_label.disabled=true;
	user_Personal_label.style.border='none';
	
	user_sex.disabled=true;
	user_sex.style.border='none';
	
	
	
	user_birthday.disabled=true;
	user_birthday.style.border='none';
	
	var modify=this_s.parentNode.parentNode.getElementsByClassName("modify")[0];
	modify.style.display='inherit';
	
	this_s.style.display='none';
	
	
	
	var temp = document.createElement("form");
	temp.action = "amodify_userinfo";
	temp.method = "post";
	temp.style.display = "none";
 
	var username =document.createElement("input");
	username.name = "username";
	username.value = user_username.value;
	temp.appendChild(username);
 
 
	var nickname =document.createElement("input");
	nickname.name = "nickname";
	nickname.value = user_nickname.value;
	temp.appendChild(nickname);
  
	var Personal_label =document.createElement("textarea");
	Personal_label.name = "Personal_label";
	Personal_label.value = user_Personal_label.value;
	temp.appendChild(Personal_label);
	
	var sex =document.createElement("input");
	sex.name = "sex";
	sex.value = user_sex.value;
	temp.appendChild(sex);
	
	var birthday =document.createElement("input");
	birthday.name = "birthday";
	birthday.value = user_birthday.value;
	temp.appendChild(birthday);
 
	document.body.appendChild(temp);
	temp.submit();
}


function deltet_userinfo(this_d){
	var user_username= this_d.parentNode.parentNode.getElementsByClassName("user_name")[0];
	window.location.href="/delet_user?username="+user_username.value;
}




function modify_businessinfo(this_m){
	var business_nickname= this_m.parentNode.parentNode.getElementsByClassName("business_nickname")[0];
	var Personal_label= this_m.parentNode.parentNode.getElementsByClassName("business_Personal_label")[0];
	var business_sex= this_m.parentNode.parentNode.getElementsByClassName("business_sex")[0];
	var business_birthday= this_m.parentNode.parentNode.getElementsByClassName("business_birthday")[0];
	business_nickname.disabled=false;
	business_nickname.style.border='inherit';
	
	Personal_label.disabled=false;
	Personal_label.style.border='inherit';
	
	business_sex.disabled=false;
	business_sex.style.border='inherit';
	
	business_birthday.disabled=false;
	business_birthday.style.border='inherit';
	
	var save=this_m.parentNode.parentNode.getElementsByClassName("save")[0];
	save.style.display='inherit';
	this_m.style.display='none';
}

function save_businessinfo(this_s){
	var business_nickname= this_s.parentNode.parentNode.getElementsByClassName("business_nickname")[0];
	var Personal_label= this_s.parentNode.parentNode.getElementsByClassName("business_Personal_label")[0];
	var business_sex= this_s.parentNode.parentNode.getElementsByClassName("business_sex")[0];
	var business_birthday= this_s.parentNode.parentNode.getElementsByClassName("business_birthday")[0];
	business_nickname.disabled=true;
	business_nickname.style.border='none';
	
	Personal_label.disabled=true;
	Personal_label.style.border='none';
	
	business_sex.disabled=true;
	business_sex.style.border='none';
	
	business_birthday.disabled=true;
	business_birthday.style.border='none';
	
	var modify=this_s.parentNode.parentNode.getElementsByClassName("modify")[0];
	modify.style.display='inherit';
	
	this_s.style.display='none';
}


function deltet_businessinfo(this_d){
	alert(this_d.className);
}