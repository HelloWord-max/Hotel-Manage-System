var aom=document.getElementsByClassName("aom");
var inhtml=document.getElementById("inhtml");
var money_recharge_ensure=document.getElementsByClassName("money_recharge_ensure")[0];

for(var i=0;i<aom.length-1;i++)
{
	aom.index=i;
	aom[i].getElementsByTagName('p')[0].onclick=function(bbs){
		switch(this.parentNode.classList[1])
		{
			case "ten-rmb":
			{
				inhtml.style.display='inherit';
				money_recharge_ensure.textContent="充值"+'10'+'元?';
				break;
			}
			case "thirty-rmb":
			{
				inhtml.style.display='inherit';
				money_recharge_ensure.textContent="充值"+'30'+'元?';
				break;
			}
			case "fifty-rmb":
			{
				inhtml.style.display='inherit';
				money_recharge_ensure.textContent="充值"+'50'+'元?';
				break;
			}
			case "hundred-rmb":
			{
				inhtml.style.display='inherit';
				money_recharge_ensure.textContent="充值"+'100'+'元?';
				break;
			}
		}
	}
}


function recharge_yes(){
	inhtml.style.display='none';
	var money=money_recharge_ensure.textContent.substring(2).replace("元?","");
	window.location.href="/recharge?money="+money;
	money_recharge_ensure.textContent="";
}

function recharge_no(){
	inhtml.style.display='none';
}

function aom_recharge(){
	var money=document.getElementById("aom-recharge").value;
	if(money=="")
	{
	}
	else{
		inhtml.style.display='inherit';
		money_recharge_ensure.textContent='充值'+money+'元?';
		console.log(money);
	}
}
