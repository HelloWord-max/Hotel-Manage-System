var hotel_list=document.getElementsByClassName("hotel-list");
var property=document.getElementsByClassName("property");

//监听网页大小
window.onresize=function(){
//监听窗口大小变化
   size();
};
function size() {
//          让centent这个div的高度一直保持当前浏览器窗口的高度
   // $("#centent").height($(window).height());
   // alert(window.innerWidth);
   if(window.innerWidth<=900)
   {
	   document.getElementsByClassName("search-frame")[0].style.display="none";
   }
   else
   {
	   document.getElementsByClassName("search-frame")[0].style.display="initial";
   }
	   // property.style.maxWidth='40%';
   


   document.getElementsByClassName("account-menu")[0].style.left=document.getElementsByClassName("user-account")[0].offsetLeft+'px';
   document.getElementsByClassName("account-menu")[0].style.top=document.getElementsByClassName("user-account")[0].offsetTop+document.getElementsByClassName("user-account")[0].offsetHeight+'px';
}
//                     最后执行
size();

function e(obj){
	return document.getElementsByClassName(obj)[0]}
 e('user-account').onclick=function(event){
	 var name=document.getElementsByClassName("account-menu")[0].classList[1];
	 if(name=="close")
	 {
		document.getElementsByClassName("account-menu")[0].className="account-menu open";
	 }
	 else
	 {
		document.getElementsByClassName("account-menu")[0].className="account-menu close";
	 }
	 stopBubble(event); 
	 document.onclick=function(){
	  var name=document.getElementsByClassName("account-menu")[0].classList[1];
	  
		document.getElementsByClassName("account-menu")[0].className="account-menu close";
	 
 　　　　　　　document.onclick=null;　
	 }
   }
	
   e('account-menu close').onclick=function(event){
	 //只阻止了向上冒泡，而没有阻止向下捕获，所以点击con的内部对象时，仍然可以执行这个函数
	 stopBubble(event); 
   }
   //阻止冒泡函数
   function stopBubble(e){  
	 if(e && e.stopPropagation){
	   e.stopPropagation();  //w3c
	 }else{
	   window.event.cancelBubble=true; //IE
	 }
  }
  
  
  function account_op(current_this){
	window.location.href=current_this.classList[1];
}


function go_main(){
	window.location.href="/main";
}