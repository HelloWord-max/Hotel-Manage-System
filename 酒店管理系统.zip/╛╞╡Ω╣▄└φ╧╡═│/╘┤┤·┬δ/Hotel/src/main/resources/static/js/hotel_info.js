var msg=document.getElementsByClassName("msg")[0];

function change_img(gss)
{
	var main_img=document.getElementsByClassName("main-img")[0].children[0];
	main_img.src=gss.children[0].src;
}

function reserve(this_r){
	var id= this_r.parentNode.parentNode.getElementsByClassName("businessid")[0];
	var type= this_r.parentNode.parentNode.getElementsByClassName("room-info-container")[0];
	var price= this_r.parentNode.parentNode.getElementsByClassName("room-price-container")[0];
	var remaining_quantity= this_r.parentNode.parentNode.getElementsByClassName("remaining-quantity-container")[0];
	var rq=remaining_quantity.getElementsByTagName("span")[0].textContent;
	rq=rq.substring(2,rq.length-1);
	var paidprice=price.getElementsByTagName("span")[0].textContent.replace("/天","");
	var businessid=id.getElementsByTagName("span")[0].textContent;
	var bedtype=type.getElementsByTagName("span")[0].textContent;
	if(rq>0)
	{
		window.location.href="/reserve?businessid="+businessid+"&bedtype="+bedtype+"&paidprice="+paidprice;
	}
	else
	{
		var msg=document.getElementsByClassName("msg")[0];
		var inhtml=document.getElementById("inhtml");
		inhtml.style.display='inherit';
		msg.textContent='预定失败：该标间已经被预定完';
	}
}


function understand(){
	var inhtml=document.getElementById("inhtml");
	inhtml.style.display='none';
	msg.textContent='';
}

