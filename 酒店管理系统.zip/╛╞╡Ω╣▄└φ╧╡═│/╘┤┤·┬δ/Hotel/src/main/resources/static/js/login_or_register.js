var login_or_register=document.getElementsByClassName("login_or_register")[0];
var form_login=document.getElementsByClassName("form-login")[0];
var form_register=document.getElementsByClassName("form-register")[0];
var form_login_or_register=document.getElementsByClassName("form-login-or-register")[0];
var down=0;
var post_way=document.getElementsByClassName("post-way")[0];
//监听网页大小
window.onresize=function(){
//监听窗口大小变化
   size();
};
function size() {
//          让centent这个div的高度一直保持当前浏览器窗口的高度
   // $("#centent").height($(window).height());
   // alert(window.innerWidth);
   login_or_register.style.left=window.innerWidth/2-login_or_register.offsetWidth/2+"px";
   login_or_register.style.top=window.innerHeight/2-login_or_register.offsetHeight/2+"px";
}
//                     最后执行
size();

var login_html=`<div class="form-login">
					<div class="type_tab">
						<h1>Sign in</h1>
					</div>
						<div class="account-and-passward">
							<div class="account">
								<input min="6" onmouseup="on_account_up()" onmousedown="on_account_down()" oninput="account_change(event)" type="text" name="username" id="account_num" autocomplete="off" placeholder="账号" />
							</div>
							<div class="passward">
								<input min="6" type="password" name="userpassword" placeholder="密码"/>
							</div>
						</div>
						<div class="login">
							<button type="submit" class="login-bt">
								登录
							</button>
						</div>
							
						</p>
						<div class="forget-passward-and-register">
							<span id="register" onclick="register()">注册</span>
							<a id="forget-passward" href="">忘记密码</a>
						</div>
					
				</div>`;
			
var register_html=`
<div class="form-register">
					<div class="rg-type_tab">
						<h1>Sign Up</h1>
					</div>
					<div class="account-and-passward-and-sure-passward">
						<div class="rg-account">
							<input min="6" type="text" name="account_num" id="account_num" autocomplete="off" value placeholder="账号" />
						</div>
						<div class="rg-passward">
							<input min="6" type="password" name="rg-passward" value placeholder="密码"/>
						</div>
						<div class="rg-sure-passward">
							<input min="6" type="password" name="rg-sure-passward" value placeholder="确认密码"/>
						</div>
					</div>
					<div class="register-button">
						<button type="submit" class="register-bt">注册</button>
					</div>
					<div class="return-login">
						<span class="ret-login" onclick="ret_login()">登录</span>
					</div>
				</div>
`;

function register(){
	var i=0;
	timer1=setInterval(function () {
	 if(i>=270)
	 {
		 form_login_or_register.innerHTML=register_html;
		 post_way.action='/user/register';
		 clearInterval(timer1);
	 }
	 else
	 {
		 i++;
		login_or_register.style.transform='rotateY('+i+'deg)';
	 }
		  //offsetLeft获取当前div的位置
	},10);
	
	timer2=setInterval(function () {
	 if(i>=360)
	 {
		 clearInterval(timer2);
	 }
	 else
	 {
		 i++;
		login_or_register.style.transform='rotateY('+i+'deg)';
	 }
		  //offsetLeft获取当前div的位置
	},10);
	
	// form_login.style.display="none";
	// form_register.style.display="inline";
}


function ret_login(){
	var i=0;
	timer1=setInterval(function () {
	 if(i>=270)
	 {
		form_login_or_register.innerHTML=login_html;
		post_way.action='/user/login';
		 clearInterval(timer1);
	 }
	 else
	 {
		 i++;
		login_or_register.style.transform='rotateY('+i+'deg)';
	 }
		  //offsetLeft获取当前div的位置
	},10);
	
	timer2=setInterval(function () {
	 if(i>=360)
	 {
		 clearInterval(timer2);
	 }
	 else
	 {
		 i++;
		login_or_register.style.transform='rotateY('+i+'deg)';
	 }
		  //offsetLeft获取当前div的位置
	},10);
}

function on_account_down(){
	var account_num=document.getElementById("account_num");
	down=1;
}

function on_account_up(){
	var account_num=document.getElementById("account_num");
	if(down==1)
	{
	}
	else
	{
		
	}
}

function close_light(){
	var meteor_shower=document.getElementsByClassName("meteor_shower")[0];
	var pObjs = meteor_shower.childNodes;
	    for (var i = pObjs.length - 1; i >= 0; i--) { 
	      meteor_shower.removeChild(pObjs[i]);
	    }
	var body=document.getElementsByTagName("body")[0];
	body.style.background='-webkit-linear-gradient(#000000 70%,#55ffff )';
	let num=40;//定义光线个数
	for(let i=0;i<num;i++)
	{
		const i =document.createElement('i');//创建光线
		i.style.height=Math.random()*80+1+20+'px';//随机光线长度为20-100
		i.style.left=Math.random()*100+1+'vw';//随机光线位置为0-100
		i.style.animationDuration=(Math.random()*25+5)/10+'s';//分别给每一个光线设置持续飞行时间
		document.querySelector('.meteor_shower').appendChild(i);//将创建的光线添加到html中
	}
	var close_light=document.getElementsByClassName("close-light")[0];
	close_light.style.display='none';
	var open_light=document.getElementsByClassName("open-light")[0];
	open_light.style.display='inherit';
}




function open_light(){
	var meteor_shower=document.getElementsByClassName("meteor_shower")[0];
	var pObjs = meteor_shower.childNodes;
	    for (var i = pObjs.length - 1; i >= 0; i--) { // 一定要倒序，正序是删不干净的，可自行尝试
	      meteor_shower.removeChild(pObjs[i]);
	    }
	var body=document.getElementsByTagName("body")[0];
	body.style.backgroundImage='url(img/loginpt.jpg)';
	body.style.backgroundRepeat='no-repeat';
	body.style.backgroundSize='cover';
	var open_light=document.getElementsByClassName("open-light")[0];
	open_light.style.display='none';
	var close_light=document.getElementsByClassName("close-light")[0];
	close_light.style.display='inherit';
}



function account_change(event){
	var account_num=document.getElementById("account_num");
}