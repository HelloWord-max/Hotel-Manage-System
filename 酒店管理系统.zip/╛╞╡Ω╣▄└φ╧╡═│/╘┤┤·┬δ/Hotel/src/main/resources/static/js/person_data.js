var el_radio=document.getElementsByClassName('el-radio-button__inner');
var el_radio_post=document.getElementsByClassName('el-radio-button__orig-radio');
var fileInput=document.getElementsByClassName('upload')[0];

for(var i=0;i<el_radio.length;i++){
	el_radio[i].index=i;//这个index就是做个介质，来获取当前的i是第几个，因为系统不会判断你这个i是第几个，智能通过中间的index来获取赋值。
	el_radio[i].onclick= function () {
		var el_radio_checked_before=document.getElementsByClassName('el-radio-button__inner this_active')[0];
		if(el_radio_checked_before!=null)
		{
			el_radio_checked_before.className='el-radio-button__inner';
		}
		el_radio_post[this.index].checked='checked';
		this.className=this.className+' this_active';
	};
}

fileInput.addEventListener('change',function()
{
	// 检查文件是否选择:
	if (!fileInput.value) {
		info.innerHTML = '没有选择文件';
		return;
	}
	// 获取File引用:
	var file = fileInput.files[0];
	
	//判断文件大小
	var size = file.size;
	
	if (file.type !== 'image/jpeg' && file.type !== 'image/png') {
		alert('不是有效的图片文件!');
		return;
	}
	// 读取文件:
	var reader = new FileReader();
	reader.onload = function(e) {
		var data = e.target.result;   	
		document.getElementsByClassName('img_head')[0].src =data ;
	};
	// 以DataURL的形式读取文件:
	reader.readAsDataURL(file);
	
	
}) 



