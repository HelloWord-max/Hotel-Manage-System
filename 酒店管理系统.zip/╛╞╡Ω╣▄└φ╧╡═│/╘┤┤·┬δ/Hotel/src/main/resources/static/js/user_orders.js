

function show_complete_orders()
{

	var living_orders=document.getElementsByClassName("order_info_list living")[0];
	if(living_orders!=null)
	{
		living_orders.style.display='none';
	}

	var incomplete_orders=document.getElementsByClassName("order_info_list incomplete")[0];
	if(incomplete_orders!=null)
	{
		incomplete_orders.style.display='none';	
	}
	
	var complete_orders=document.getElementsByClassName("order_info_list complete")[0];
	
	if(complete_orders!=null)
	{
		complete_orders.style.display='block';
	}
}


function show_incomplete_orders()
{
	var living_orders=document.getElementsByClassName("order_info_list living")[0];
	if(living_orders!=null)
	{
		living_orders.style.display='none';
	}

	var complete_orders=document.getElementsByClassName("order_info_list complete")[0];
	if(complete_orders!=null)
	{
		complete_orders.style.display='none';
	}
	
	var incomplete_orders=document.getElementsByClassName("order_info_list incomplete")[0];
	
	
	if(incomplete_orders!=null)
	{
		incomplete_orders.style.display='block';
	}
}

function show_living_orders()
{
	var complete_orders=document.getElementsByClassName("order_info_list complete")[0];
	if(complete_orders!=null)
	{
		complete_orders.style.display='none';
	}
	
	var incomplete_orders=document.getElementsByClassName("order_info_list incomplete")[0];
	
	
	if(incomplete_orders!=null)
	{
		incomplete_orders.style.display='none';
	}
	
	var living_orders=document.getElementsByClassName("order_info_list living")[0];
	if(living_orders!=null)
	{
		living_orders.style.display='block';
	}
}

function cancel(this_c){
	var order_num=this_c.parentNode.parentNode.parentNode.getElementsByClassName("order_num")[0].value;
	window.location.href="/cancel?order_num="+order_num;
}